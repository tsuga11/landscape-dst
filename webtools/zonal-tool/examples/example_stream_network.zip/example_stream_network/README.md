# Example stream network package (synthetic)

A made-up basin for trying the Zonal tool's Stream network zones. Nothing here
comes from a real network, site inventory or image. The format is
`docs/SPEC-stream-network-package.md` in erc-tools; the generator is
`tools/make_example_network.py`.

To use it: choose Stream network in the Zones panel, then press "Try the
example package" on the Data panel. The tool ships this exact file. Or drop
this zip, or the unzipped folder, on the Data panel.

| File | What it holds |
|---|---|
| `manifest.json` | Hydrography, flow units, column units, a checksum per file |
| `reaches.parquet` | 22 reaches: `reach_id`, `down_id`, length, reservoir flag, outlet type, two flows (cfs and m3/s), riparian condition (one value missing on purpose), and a stream name (text, so the tool ignores it) |
| `sites.csv` | 12 sites. 8 barriers (`breaks_network` = 1): 6 dams, culverts and a diversion, 1 natural falls (not in the output), 1 failed snap (left out), 1 snap marked for review. 4 sites that do not break the network: a gauge, two survey reaches, an eDNA site. Plus name, type, feasibility, local support and owner |
| `catchments.tif` | Int32, cell value = `reach_id`, 0 outside the basin |
| `overland_dist.tif` | Float32 meters to the nearest stream |
| `corridor.tif` | UInt8 valley bottom, 1 inside |
| `condition/canopy_pct.tif`, `condition/impervious_pct.tif` | Float32 percent, -9999 outside the basin |

30 m cells, 300 × 240, EPSG:5070. Tiled, DEFLATE.

Things worth looking at in the output:

- The reach table has a row for all 22 reaches: canopy in each reach's own
  catchment (`cat`) and in everything draining to it (`ws`). `net_segment`
  names the barrier at the bottom of the segment each reach sits in.
- The gauge's watershed (`ws`) is nearly the whole basin; the eDNA site's is
  one headwater. Sites that do not break the network have no segment columns.
- Hollow Creek Dam sits at the bottom of a reservoir (pos_from_down 0.03 on an
  artificial-path reach): its upstream segment carries the reservoir length in
  `net_up_resv_km`.
- Lost Falls is natural: it bounds segments and is counted in
  `net_n_down_natural` for the sites above it, but has no row.
- "Barrier removal setup" on the Zones panel gives the segment view for the
  barriers alone.
