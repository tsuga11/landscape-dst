# Example stream network package (synthetic)

A made-up basin for trying the Zonal tool's Stream network zones. Nothing here
comes from a real network, barrier inventory or image. The format is
`docs/SPEC-stream-network-package.md` in erc-tools.

To use it: choose Stream network in the Zones panel, then press "Try the
example package" on the Data panel. The tool ships this exact file. Or drop
this zip, or the unzipped folder, on the Data panel.

| File | What it holds |
|---|---|
| `manifest.json` | Hydrography, flow units, column units, a checksum per file |
| `reaches.parquet` | 22 reaches: `reach_id`, `down_id`, length, reservoir flag, outlet type, two flows (cfs and m3/s), riparian condition (one value missing on purpose), and a stream name (text, so the tool ignores it) |
| `barriers.csv` | 8 barriers: 6 candidate dams and culverts, 1 natural falls, 1 failed snap (left out), 1 snap marked for review; plus name, type, feasibility, local support and owner |
| `catchments.tif` | Int32, cell value = `reach_id`, 0 outside the basin |
| `overland_dist.tif` | Float32 meters to the nearest stream |
| `corridor.tif` | UInt8 valley bottom, 1 inside |
| `condition/canopy_pct.tif`, `condition/impervious_pct.tif` | Float32 percent, -9999 outside the basin |

30 m cells, 300 × 240, EPSG:5070. Tiled, DEFLATE.

Things worth looking at in the output:

- Hollow Creek Dam sits at the bottom of a reservoir (pos_from_down 0.03 on an
  artificial-path reach): its upstream zone carries the reservoir length in
  `net_up_resv_km`.
- Lost Falls is natural: it breaks zones, has no row, and is counted in
  `net_n_down_natural` for the dams above it.
- Fork Rd culvert sits at 0.60 on its reach, past the midpoint, so its own
  catchment counts downstream (`net_own_side` = down). Tick the sensitivity
  option to see `up-alt` / `down-alt`.
